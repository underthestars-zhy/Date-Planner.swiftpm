#import <Foundation/Foundation.h>

//! Project version number for Introspect.
FOUNDATION_EXPORT double IntrospectVersionNumber;

//! Project version string for Introspect.
FOUNDATION_EXPORT const unsigned char IntrospectVersionString[];
