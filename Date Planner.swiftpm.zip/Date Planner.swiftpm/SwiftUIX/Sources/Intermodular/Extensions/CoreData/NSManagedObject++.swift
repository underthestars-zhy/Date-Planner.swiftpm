//
// Copyright (c) Vatsal Manot
//

import CoreData
import Swift
import SwiftUI

extension NSObjectProtocol where Self: NSManagedObject {

}
