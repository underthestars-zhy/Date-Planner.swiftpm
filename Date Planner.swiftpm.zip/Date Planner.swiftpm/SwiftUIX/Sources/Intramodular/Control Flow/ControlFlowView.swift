//
// Copyright (c) Vatsal Manot
//

import Swift
import SwiftUI

/// A view representing some form of control flow.
public protocol ControlFlowView: View {
    
}
