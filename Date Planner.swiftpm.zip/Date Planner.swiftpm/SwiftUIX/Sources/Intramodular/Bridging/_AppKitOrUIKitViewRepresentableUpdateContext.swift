//
// Copyright (c) Vatsal Manot
//

import Swift
import SwiftUI

struct _AppKitOrUIKitViewRepresentableUpdate: Hashable {
    let generation: AnyHashable = UUID()

    init() {

    }
}
