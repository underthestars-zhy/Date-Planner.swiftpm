//
//  File.swift
//  
//
//  Created by 朱浩宇 on 2022/4/6.
//

import Foundation

struct FRect {
    let x: Double
    let y: Double
    let width: Double
    let height: Double
}
