//
//  BeFriend.swift
//  
//
//  Created by 朱浩宇 on 2022/4/8.
//

import SwiftUI

public protocol BeFriend {
    var eternalId: String { get }
}
